- **項目名稱 / Project Name**：
    
    Python 連接 PLC Delta-SE系列，實現"讀取"和"寫入"功能<br>
    
    Python Connect to Delta-SE Series for "Read" and "Write" Functions <br>

- **支援 PLC / Support PLC**：
    
    Delta-SE Series (Ethernet)


## Language / 語言

- [English README](docs/English_README.md)
- [中文 README](docs/Chinese_README.md)
